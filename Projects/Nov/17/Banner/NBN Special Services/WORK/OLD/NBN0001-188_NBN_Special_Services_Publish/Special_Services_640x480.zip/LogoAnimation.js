(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.nbn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4B5F6B").s().p("AgRATIgBgCQAAAAAAgBQABAAAAgBQAAAAABAAQAAAAABAAIABAAQAHAHAJAAQAMAAAAgKQAAgHgOgDQgQgCAAgLQAAgGAEgEQAFgEAHAAQAHAAAJAFIABACQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBAAIgBAAQgHgFgGAAQgLAAAAAJQAAAIANADQARACAAALIAAAAQAAAGgFAEQgFAEgIAAQgJAAgJgHg");
	this.shape.setTransform(106.5,35.4,2.677,2.677);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4B5F6B").s().p("AgRATIgBgCQAAAAAAgBQABAAAAgBQAAAAABAAQAAAAABAAIABAAQAHAHAJAAQAMAAAAgKQAAgHgOgDQgQgCAAgLQAAgGAEgEQAFgEAHAAQAHAAAJAFIABACQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBAAIgBAAQgGgFgHAAQgLAAAAAJQAAAIANADQARACAAALIAAAAQAAAGgFAEQgFAEgIAAQgJAAgJgHg");
	this.shape_1.setTransform(91.5,35.4,2.677,2.677);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B5F6B").s().p("AgPAZQgBAAAAAAQgBAAAAAAQAAAAgBgBQAAAAAAgBIAAgtQAAAAAAgBQABAAAAgBQAAAAABAAQAAAAABAAIAfAAQABAAAAAAQABAAAAAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAAAgBAAIgdAAIAAATIAaAAQAAAAABAAQAAAAAAAAQAAAAABABQAAAAAAAAQAAAAAAABQgBAAAAABQAAAAAAAAQgBAAAAAAIgaAAIAAATIAdAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAAAgBAAg");
	this.shape_2.setTransform(77.4,35.1,2.677,2.677);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4B5F6B").s().p("AATAaIgDgCIgggpIAAAoQAAABAAAAQAAABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBIAAgtQAAgBAAAAQAAgBAAAAQABAAAAgBQAAAAABAAIABAAIACACIAgAoIAAgnQAAgBAAAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQAAAAAAABIAAAtQAAABAAAAQAAABAAAAQAAAAgBABQAAAAgBAAg");
	this.shape_3.setTransform(60.5,35.2,2.677,2.677);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4B5F6B").s().p("AgCAXIAAgtQAAgBABAAQAAgBAAAAQAAAAABgBQAAAAAAAAQABAAAAAAQABABAAAAQAAAAAAABQABAAAAABIAAAtQAAABgBAAQAAABAAAAQAAAAgBABQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBg");
	this.shape_4.setTransform(48.1,35.2,2.677,2.677);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4B5F6B").s().p("AgRATIgBgCQAAAAAAgBQABAAAAgBQAAAAABAAQAAAAABAAIABAAQAHAHAJAAQAMAAAAgKQAAgHgOgDQgQgCAAgLQAAgGAFgEQAFgEAGAAQAIAAAIAFIABACQAAAAAAABQAAAAgBABQAAAAAAAAQgBAAAAAAIgCAAQgGgFgHAAQgEAAgEADQgDACAAAEQAAAIANADQARACAAALIAAAAQAAAGgFAEQgFAEgHAAQgJAAgKgHg");
	this.shape_5.setTransform(37.1,35.4,2.677,2.677);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4B5F6B").s().p("AgUAEIAAgbQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABAAAAIAAAaQAAASAQAAQAPABAAgSIAAgbQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABAAAAIAAAaQAAAXgVAAQgUAAAAgWg");
	this.shape_6.setTransform(21.5,35.3,2.677,2.677);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4B5F6B").s().p("AgRAZQAAAAgBAAQAAAAgBAAQAAAAAAgBQAAAAAAgBIAAgtQAAAAAAgBQAAAAAAgBQABAAAAAAQABAAAAAAIASAAQAJAAAEAEQAEAEAAAEQAAAJgJADQALACAAAJIAAABQAAANgSAAgAgPAVIARAAQAOAAAAgKQAAgJgPAAIgQAAgAgPgBIAPAAQANAAAAgKQAAgJgMAAIgQAAg");
	this.shape_7.setTransform(5.1,35.1,2.677,2.677);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#223D79").s().p("AAVAoQgDgDAAgEIAAglQAAgUgSAAQgHAAgFAFQgFAGAAAJIAAAlQAAAKgKAAQgJAAAAgKIAAhAQAAgKAJAAQAKAAAAAKIAAAEQAKgPAPAAQAOAAAHAJQAIAJAAAOIAAArQAAAKgJAAQgEAAgDgDg");
	this.shape_8.setTransform(42.8,13.7,1.858,1.858);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#223D79").s().p("AgXAsIAAAEQAAAEgDADQgCADgEAAQgKAAAAgKIAAhgQAAgEADgDQADgDAEAAQAEAAACADQADADAAAEIAAAlQALgQAQAAQAQAAALALQAMANAAASIAAABQAAAUgMAMQgLALgQAAQgQAAgLgPgAgQgDQgHAHAAALIAAABQAAALAHAIQAHAHAJAAQAKAAAHgHQAHgHAAgMIAAgBQAAgLgHgHQgHgHgKAAQgJAAgHAHg");
	this.shape_9.setTransform(25.1,10.9,1.858,1.858);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#223D79").s().p("AASAhIAAglQABgUgTAAQgHAAgFAFQgFAGAAAJIAAAlQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAhAQAAgEADgDQADgDAEAAQAEAAADADQADADAAAEIAAAEQAJgPAPAAQAOAAAJAJQAHAJAAAOIAAArQAAAEgDADQgCADgEAAQgKAAAAgKg");
	this.shape_10.setTransform(7,13.7,1.858,1.858);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#223D79").s().p("AAFAHIAAgJIgEAFIgBABIAAgBIgEgFIAAAJQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAAAAAgBIAAgNQAAgBAAAAQAAAAAAAAQAAgBABAAQAAAAAAAAIABAAIABABIAEAHIAFgHIACgBQAAAAAAAAQABAAAAABQAAAAAAAAQAAAAAAABIAAANQAAABAAAAQAAAAAAAAQAAABgBAAQAAAAAAAAg");
	this.shape_11.setTransform(52,3.7,1.858,1.858);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#223D79").s().p("AgBAHIAAgMIgEAAQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIAKAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAABQgBAAAAAAQAAAAgBAAIgDAAIAAAMQAAAAgBABQAAAAAAAAQAAAAAAAAQgBABAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBgBAAAAg");
	this.shape_12.setTransform(48.6,3.7,1.858,1.858);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.nbn, new cjs.Rectangle(-0.3,0,111.9,42.4), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AqGDgQgDgDAAgDIAAiJQAAgEADgDQACgCADAAQAEAAACACQADADAAAEIAAAPIAIgKIAKgIQAGgEAGgBQAHgDAHAAQALAAAKAEQAKAFAIAHQAIAIAFALQAEAQAAAKIAAAAIgBAOIgDAMQgFALgIAIQgIAHgKAFQgKAEgLAAQgHAAgHgCQgGgCgGgEQgGgDgEgFIgIgJIAAAzQAAADgCADQgDACgEAAQgDAAgCgCgApeBZQgIADgFAGQgHAHgDAIQgDAIgBAKIAAAAQABAKADAJQADAIAHAGQAFAGAIADQAHADAJAAQAIAAAIgDQAHgDAFgGQAGgGADgIQADgIAAgLQAAgKgDgJQgDgIgGgGQgFgGgHgDQgIgDgIAAQgJAAgHADgAJmC8QgKgFgIgIQgJgIgEgLIgDgMIgBgNQAAgMAEgMQAEgLAIgIQAHgIAKgFQAKgFAMAAQAJAAAPAFQAJAFAIAIQAGAIAEALQADALAAALQABAEgDACQgDADgDAAIhUAAQABAJAEAHQADAHAGAGQAFAFAIACQAGADAIAAQAKAAAJgEQAIgDAGgHQADgCADAAQADAAACADQADACAAADQgBADgDACQgIAJgKAEQgPAFgLAAQgLAAgLgEgAKfB9QAAgIgDgHQgDgIgFgFQgEgGgGgDQgIgDgIAAQgIAAgGADQgGADgGAFQgEAGgEAHQgDAHgBAJIBLAAIAAAAgAH/C/IgLgEQgLgFgIgIQgIgIgEgLQgFgLAAgMIAAgBQAAgMAFgLQAEgLAIgIQAIgJALgFIALgDIANgCQAJAAAQAFQAJAEAJAIQACADAAADQAAAEgCACQgDADgDAAQgEAAgCgCQgHgHgGgDQgJgEgJAAQgJAAgIADQgIAEgFAGQgGAGgDAIQgDAJAAAJIAAAAQAAAJADAJQAEAIAFAGQAGAGAIAEQAIADAJAAQAJAAAJgEQAHgDAHgHQACgCADAAQADAAADACQACADAAADQAAADgCACQgJAJgKAFIgMAEIgNABgACLC8QgKgFgIgIQgIgIgEgLIgEgMIgBgNQAAgMAFgMQAEgLAHgIQAHgIALgFQAKgFAMAAQAJAAAOAFQAKAFAHAIQAHAIAEALQADALAAALQAAAEgDACQgCADgDAAIhVAAQABAJAFAHQACAHAHAGQAFAFAHACQAHADAIAAQAKAAAJgEQAHgDAHgHQACgCADAAQADAAADADQACACAAADQAAADgDACQgJAJgKAEQgPAFgKAAQgMAAgLgEgADEB9QAAgIgDgHQgDgIgEgFQgFgGgGgDQgHgDgJAAQgHAAgGADQgHADgFAFQgFAGgDAHQgEAHgBAJIBLAAIAAAAgAjXC9QgJgCgGgEQgFgFgEgHQgEgHAAgIIAAgBQAAgJAEgHQADgHAHgFQAGgFAKgCQAIgCAMAAQAOAAAVAEIAAgEQAAgHgCgGQgCgGgFgEQgEgEgGgCQgHgCgIAAQgIAAgJACQgGABgHADIgEABQgCAAgDgCQgCgDAAgDQAAgFAEgCQAKgEAIgCQAKgCAKAAQANAAAKAEQAJADAGAGQAGAGAEAJQACAIAAALIAABAQAAAEgCACQgCACgEAAQgEAAgCgCQgCgCgBgEIAAgKQgHAJgJAFQgFADgGABQgHACgIAAQgIAAgHgDgAjOCEQgGACgFADQgEADgCAEQgDAFAAAFIAAABQAAAFADAFQACAEAEADQAFADAEABQAGACAGAAQAIAAAHgCQAHgDAGgEQAFgEADgGQADgGAAgGIAAgMQgVgFgOAAQgHAAgHACgAliC/IgLgEQgLgFgIgIQgJgIgEgLQgEgLAAgMIAAgBQAAgMAEgLQAEgLAJgIQAIgJALgFIALgDIAMgCQAKAAAPAFQAJAEAJAIQADADAAADQAAAEgDACQgCADgDAAQgEAAgCgCQgIgHgGgDQgJgEgJAAQgJAAgHADQgIAEgGAGQgGAGgDAIQgCAJAAAJIAAAAQAAAJACAJQAEAIAFAGQAHAGAHAEQAIADAJAAQAJAAAJgEQAIgDAGgHQADgCADAAQADAAACACQADADAAADQAAADgDACQgJAJgKAFIgLAEIgOABgAnlC8QgLgFgIgIQgIgIgFgLIgCgMIgCgNQAAgMAEgMQAEgLAIgIQAIgIAJgFQALgFAMAAQAJAAAOAFQAKAFAHAIQAGAIAEALQAEALAAALQAAAEgCACQgDADgDAAIhUAAQABAJADAHQAEAHAFAGQAGAFAHACQAHADAHAAQALAAAIgEQAIgDAHgHQADgCACAAQADAAACADQADACAAADQAAADgDACQgJAJgJAEQgQAFgKAAQgMAAgKgEgAmsB9QgBgIgCgHQgDgIgFgFQgFgGgGgDQgHgDgIAAQgIAAgHADQgGADgFAFQgFAGgEAHQgCAHgBAJIBLAAIAAAAgALRC8QgNgEgJgHQgDgCAAgEQAAgEACgCQADgCADAAQAAAAABAAQAAAAABABQAAAAABAAQABAAAAABQAJAGAJADQAJADAKAAQAKAAAHgFQAHgFAAgJIAAAAQAAgEgCgEIgHgFQgGgEgOgDQgTgGgHgFQgGgEgDgFQgDgGAAgHIAAgBQAAgHACgGQADgHAGgEQAFgEAHgDQAIgCAIAAQAJAAAKADQAJACAJAFQAFACAAAFQAAADgDACQgCACgDAAIgEAAQgIgFgHgCQgJgCgGAAQgLAAgGAEQgGAFAAAHIAAABQAAAEADADQACADAEACQAFADAQAFIANAEIANAHQAFAEADAFQADAGAAAHIAAABQAAAIgDAGQgDAHgGAEQgFAFgIACQgIACgIAAQgLAAgMgDgAFiC/QgHAAgCgHIgthjIAAgFQgBgDADgDQADgCAEAAQAFAAADAHIAlBaIAnhbQACgGAGAAQADAAADACQADADgBADIAAAFIgsBjQgEAHgGAAgAAVC+IgPgEQgHgCgGgEIgOgKQgDgCAAgEQAAgEACgDQACgCAFAAQACAAACACQAIAGAPAIIAMADIAPACQAHAAAHgCQAGgCAFgEQAFgEACgFQACgEABgGIAAgBQgBgFgBgFQgCgEgEgEQgFgDgIgDIgVgGQgNgDgKgDQgJgEgGgGQgHgFgDgHQgEgHAAgKIAAgBQAAgJAFgIQADgHAHgGQAHgGAJgDQAKgDAKAAQALAAARADQAMAEALAIQADADAAAEQABAEgDACQgDADgDAAQgDAAgCgCQgKgHgKgDQgKgEgLAAQgIAAgGACQgGACgFAEQgEADgCAFQgCAFAAAFIAAAAQAAAGACAEQABAFAFADQAFAEAIADQAJADAMADQANADAKAEQAKAEAGAFQAGAFADAHQAEAIAAAJQAAAKgFAIQgDAIgIAGQgHAGgKADQgKADgLAAIgRgBgArjC+IgPgEQgIgCgHgEIgNgKQgEgCAAgEQABgEACgDQACgCAEAAQADAAACACQAIAGAPAIIANADIAOACQAHAAAIgCQAGgCAEgEQAFgEADgFQACgEAAgGIAAgBQAAgFgCgFQgCgEgEgEQgFgDgHgDIgVgGQgOgDgKgDQgKgEgGgGQgHgFgDgHQgDgHAAgKIAAgBQAAgJAEgIQAEgHAHgGQAHgGAJgDQAKgDALAAQAKAAASADQALAEALAIQAEADAAAEQAAAEgDACQgCADgDAAQgEAAgCgCQgJgHgKgDQgLgEgLAAQgHAAgGACQgGACgFAEQgEADgDAFQgCAFAAAFIAAAAQAAAGACAEQACAFAFADQAEAEAIADQAJADANADQANADAJAEQAKAEAHAFQAGAFADAHQADAIAAAJQAAAKgEAIQgEAIgHAGQgIAGgJADQgKADgMAAIgQgBgAGuC8QgCgDgBgDIAAhlQABgEACgDQACgCAEAAQAEAAACACQACADABAEIAABlQAAADgCADQgDACgEAAQgEAAgCgCgADqC8QgDgDAAgDIAAhlQAAgEADgDQACgCADAAQAEAAADACQACADAAAEIAAAVIAIgNQAEgFAGgEIALgHQAGgCAFAAQAEAAACADQADACAAAEQAAAIgIABQgIABgIAEQgIAEgFAGQgFAHgDAJQgEAKAAAMIAAAoQAAADgCADQgCACgFAAQgDAAgCgCgAhxC8QgDgDAAgDIAAiVQAAgEADgCQACgDAEAAQADAAACADQADACAAAEIAACVQAAADgCADQgCACgEAAQgEAAgCgCgAkTC8QgDgDAAgDIAAhlQAAgEADgDQACgCAEAAQADAAACACQADADAAAEIAABlQAAADgCADQgCACgEAAQgEAAgCgCgAGtAuQgDgDAAgEIAAgDQAAgEADgCQACgDAFAAQAFAAADADQACACAAAEIAAADQAAAEgCADQgDADgFAAQgFAAgCgDgAkUAuQgDgDgBgEIAAgDQABgEADgCQACgDAFAAQAEAAADADQADACAAAEIAAADQAAAEgDADQgDADgEAAQgFAAgCgDgAT+g8QgJgCgGgEQgFgFgEgHQgEgHAAgIIAAgBQAAgJAEgHQADgHAHgFQAGgFAKgCQAIgCAMAAQAOAAAWAEIAAgEQgBgHgCgGQgCgGgEgEQgFgEgGgCQgHgCgIAAQgIAAgJACQgGABgHADIgEABQgCAAgDgCQgCgDAAgDQAAgFAEgCQAKgEAIgCQAKgCAKAAQANAAAKAEQAJADAGAGQAGAGAEAJQACAIAAALIAABAQAAAEgCACQgCACgEAAQgEAAgCgCQgCgCAAgEIAAgKQgIAJgJAFQgFADgGABQgHACgIAAQgIAAgHgDgAUHh1QgGACgFADQgEADgCAEQgDAFAAAFIAAABQAAAFADAFQACAEAEADQAFADAEABQAGACAGAAQAIAAAHgCQAHgDAGgEQAFgEADgGQADgGAAgGIAAgMQgVgFgOAAQgHAAgHACgASgg6IgLgEQgKgFgJgIQgIgIgFgLQgEgLAAgMIAAgBQAAgMAEgLQAFgLAIgIQAJgJAKgFIALgDIANgCQAJAAAPAFQAKAEAIAIQADADAAADQAAAEgDACQgCADgDAAQgEAAgCgCQgHgHgGgDQgJgEgJAAQgJAAgIADQgHAEgGAGQgGAGgDAIQgDAJAAAJIAAAAQAAAJADAJQADAIAGAGQAGAGAIAEQAHADAKAAQAJAAAJgEQAHgDAHgHQACgCADAAQADAAACACQADADAAADQAAADgDACQgIAJgKAFIgMAEIgNABgAM4g6IgLgEQgKgFgJgIQgIgIgFgLQgEgLAAgMIAAgBQAAgMAEgLQAFgLAIgIQAJgJAKgFIALgDIANgCQAJAAAPAFQAKAEAIAIQADADAAADQAAAEgDACQgCADgDAAQgEAAgCgCQgHgHgGgDQgJgEgJAAQgJAAgIADQgHAEgGAGQgGAGgDAIQgDAJAAAJIAAAAQAAAJADAJQADAIAGAGQAGAGAIAEQAHADAKAAQAJAAAJgEQAHgDAHgHQACgCADAAQADAAACACQADADAAADQAAADgDACQgIAJgKAFIgMAEIgNABgAGig9QgKgFgIgIQgJgIgEgLIgDgMIgCgNQABgMAEgMQAEgLAIgIQAHgIAKgFQAKgFAMAAQAJAAAPAFQAJAFAIAIQAGAIAEALQAEALgBALQAAAEgCACQgDADgDAAIhUAAQABAJAEAHQADAHAGAGQAGAFAGACQAIADAHAAQALAAAIgEQAIgDAGgHQADgCADAAQADAAACADQACACABADQAAADgEACQgIAJgKAEQgQAFgJAAQgMAAgLgEgAHbh8QAAgIgDgHQgDgIgFgFQgEgGgHgDQgHgDgIAAQgHAAgHADQgGADgGAFQgFAGgDAHQgDAHgBAJIBLAAIAAAAgAAUg9QgIgDgHgGQgFgGgCgJQgDgIAAgLIAAhAQAAgEACgDQADgCADAAQADAAADACQACADABAEIAAA8QAAAIABAHQACAGAFAFQAEAEAGADQAGACAHAAQAIAAAHgDQAFgCAFgFQAFgFACgHQADgGAAgJIAAg6QAAgEADgDQADgCADAAQADAAADACQADADgBAEIAABlQABADgDADQgDACgDAAQgDAAgDgCQgDgDAAgDIAAgNQgIAMgHAEQgFADgGACQgGACgHAAQgLAAgIgEgAhcg7QgGgCgGgEQgFgDgEgFIgJgJIAAAPQAAADgBADQgDACgEAAQgEAAgCgCQgCgDgBgDIAAiVQABgEACgDQACgCAEAAQAEAAACACQACADAAAEIAAA/IAJgKIAJgIQAGgEAGgBQAIgDAHAAQAKAAAKAEQALAFAHAHQAJAIAEALQAFAQAAAKIAAAAIgCAOIgDAMQgEALgJAIQgHAHgLAFQgJAEgLAAQgHAAgIgCgAhfigQgIADgGAGQgGAHgEAIQgDAIAAAKIAAAAQAAAKADAJQAEAIAGAGQAGAGAIADQAHADAIAAQAIAAAIgDQAHgDAGgGQAGgGADgIQADgIAAgLQAAgKgDgJQgDgIgGgGQgGgGgHgDQgIgDgIAAQgIAAgHADgAlzg9QgIgDgGgGQgFgGgDgJQgDgIgBgLIAAhAQAAgEADgDQACgCAEAAQADAAADACQADADAAAEIAAA8QAAAIACAHQACAGAEAFQAFAEAFADQAHACAHAAQAIAAAGgDQAGgCAFgFQAFgFACgHQADgGAAgJIAAg6QAAgEACgDQADgCAEAAQADAAACACQADADAAAEIAABlQAAADgDADQgCACgDAAQgEAAgDgCQgCgDAAgDIAAgNQgJAMgHAEQgFADgFACQgHACgHAAQgKAAgJgEgAnlg6IgMgEQgLgEgJgJQgHgIgFgLQgEgLgBgMIAAgBQABgMAEgLQAFgLAIgIQAIgJALgFIAMgDIAMgCQAJAAAQAFQAKAFAJAIQAIAJAEALQAFALAAAMIAAAAQAAAMgFAMQgEALgIAIQgJAIgKAFQgRAFgIAAgAnrigQgHAEgGAGQgFAGgDAIQgEAJAAAJIAAAAQAAAJAEAJQADAIAGAGQAGAGAHAEQAIADAJAAQAJAAAJgDQAHgEAGgGQAGgGADgIQADgIAAgJIAAgBQAAgJgDgIQgEgJgFgGQgGgGgIgEQgIgDgJAAQgJAAgJADgApng7QgGgCgFgEQgGgDgEgFIgIgJIAAAPQAAADgCADQgDACgEAAQgEAAgCgCQgCgDgBgDIAAiVQABgEACgDQACgCAEAAQAEAAACACQACADABAEIAAA/IAIgKIAKgIQAFgEAGgBQAIgDAHAAQAKAAAKAEQALAFAHAHQAJAIAEALQAFAQAAAKIAAAAIgBAOIgEAMQgEALgJAIQgHAHgLAFQgJAEgLAAQgHAAgIgCgApqigQgIADgGAGQgGAHgEAIQgDAIAAAKIAAAAQAAAKADAJQAEAIAGAGQAGAGAIADQAHADAIAAQAJAAAHgDQAHgDAGgGQAGgGADgIQADgIAAgLQAAgKgDgJQgEgIgFgGQgGgGgHgDQgHgDgJAAQgIAAgHADgAr4g8QgHgCgGgEQgHgFgDgHQgEgHAAgIIAAgBQAAgJADgHQAEgHAHgFQAHgFAIgCQAJgCAMAAQAOAAAWAEIAAgEQAAgHgDgGQgCgGgEgEQgFgEgHgCQgGgCgIAAQgJAAgHACQgIABgGADIgEABQgCAAgDgCQgCgDAAgDQAAgFAFgCQAJgEAJgCQAJgCALAAQAMAAAJAEQAKADAGAGQAGAGADAJQADAIAAALIAABAQAAAEgCACQgDACgDAAQgEAAgCgCQgCgCAAgEIAAgKQgIAJgJAFQgFADgHABQgGACgHAAQgJAAgIgDgAruh1QgGACgFADQgEADgCAEQgCAFgBAFIAAABQABAFACAFQACAEAEADQAFADAEABQAGACAGAAQAIAAAHgCQAHgDAFgEQAGgEADgGQADgGAAgGIAAgMQgUgFgOAAQgJAAgGACgAxsg8QgIgCgHgEQgFgFgEgHQgEgHAAgIIAAgBQAAgJADgHQAEgHAHgFQAGgFAKgCQAJgCALAAQAPAAAUAEIAAgEQABgHgDgGQgCgGgFgEQgEgEgGgCQgHgCgIAAQgJAAgIACQgGABgHADIgDABQgDAAgDgCQgCgDAAgDQAAgFAEgCQAKgEAIgCQAKgCAKAAQANAAAKAEQAJADAGAGQAGAGAEAJQACAIAAALIAABAQAAAEgCACQgCACgEAAQgEAAgCgCQgCgCgBgEIAAgKQgHAJgJAFQgFADgHABQgGACgIAAQgIAAgHgDgAxjh1QgGACgEADQgFADgCAEQgCAFAAAFIAAABQAAAFACAFQACAEAFADQADADAGABQAFACAGAAQAIAAAHgCQAHgDAGgEQAFgEADgGQADgGAAgGIAAgMQgVgFgOAAQgHAAgHACgAzbg9QgKgFgIgIQgIgIgFgLIgCgMIgCgNQAAgMAEgMQAEgLAIgIQAHgIAKgFQALgFAMAAQAJAAAOAFQAJAFAIAIQAGAIAEALQAEALAAALQAAAEgDACQgCADgDAAIhVAAQACAJADAHQAEAHAFAGQAGAFAHACQAHADAHAAQALAAAIgEQAIgDAHgHQACgCADAAQAEAAACADQACACAAADQAAADgDACQgJAJgJAEQgQAFgKAAQgLAAgMgEgAyhh8QgBgIgDgHQgDgIgEgFQgFgGgGgDQgHgDgIAAQgIAAgHADQgGADgFAFQgFAGgDAHQgDAHgCAJIBMAAIAAAAgAQYg8QgHgBgDgEQgFgEgDgGQgCgHAAgJIAAhGIgJAAQgDAAgDgCQgCgCAAgDQAAgEACgCQADgCADAAIAJAAIAAgcQAAgDACgDQADgCAEAAQADAAACACQADADAAADIAAAcIAeAAQADAAADACQACADAAADQAAADgCACQgDACgDAAIgeAAIAABEQAAAKAFAFQAGAFAJAAQAGAAAEgCQAEAAACACQACACAAADQAAAFgFACQgIADgKAAQgGAAgGgCgAJvg9QgMgEgKgHQgDgCAAgEQAAgEACgCQADgCADAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAKAGAIADQAKADAKAAQAKAAAGgFQAIgFgBgJIAAAAQABgEgDgEIgHgFQgFgEgPgDQgTgGgHgFQgGgEgDgFQgDgGAAgHIAAgBQAAgHACgGQADgHAGgEQAGgEAGgDQAIgCAIAAQAJAAAKADQAKACAIAFQAFACAAAFQAAADgDACQgBACgEAAIgEAAQgHgFgIgCQgIgCgHAAQgKAAgHAEQgFAFAAAHIAAABQAAAEACADQACADAFACQAFADAQAFIANAEIAMAHQAFAEAEAFQADAGAAAHIAAABQAAAIgDAGQgEAHgFAEQgGAFgIACQgHACgJAAQgLAAgMgDgAINg9QgMgEgKgHQgDgCAAgEQAAgEACgCQADgCADAAQAAAAABAAQAAAAABABQAAAAABAAQABAAAAABQAJAGAJADQAJADAKAAQALAAAGgFQAHgFAAgJIAAAAQAAgEgDgEIgGgFQgGgEgPgDQgSgGgIgFQgFgEgDgFQgEgGABgHIAAgBQgBgHADgGQADgHAFgEQAGgEAHgDQAHgCAJAAQAJAAAKADQAJACAJAFQAEACABAFQgBADgCACQgCACgDAAIgEAAQgIgFgHgCQgIgCgIAAQgKAAgGAEQgGAFAAAHIAAABQAAAEADADQACADAEACQAGADAPAFIANAEIANAHQAFAEADAFQADAGAAAHIAAABQAAAIgDAGQgDAHgGAEQgGAFgHACQgHACgJAAQgLAAgMgDgACIg9QgMgEgKgHQgDgCABgEQgBgEACgCQADgCADAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQAKAGAIADQAKADAJAAQALAAAGgFQAIgFgBgJIAAAAQABgEgDgEIgHgFQgFgEgPgDQgSgGgIgFQgGgEgDgFQgDgGAAgHIAAgBQAAgHADgGQADgHAFgEQAGgEAGgDQAIgCAIAAQAJAAAKADQAKACAIAFQAFACAAAFQAAADgDACQgCACgDAAIgEAAQgHgFgIgCQgIgCgHAAQgKAAgHAEQgFAFgBAHIAAABQAAAEADADQACADAEACQAGADAQAFIANAEIAMAHQAGAEADAFQADAGAAAHIAAABQAAAIgDAGQgEAHgFAEQgGAFgIACQgHACgJAAQgLAAgMgDgAj0g8QgGgBgEgEQgFgEgCgGQgCgHgBgJIAAhGIgJAAQgDAAgCgCQgDgCAAgDQAAgEADgCQACgCADAAIAJAAIAAgcQABgDACgDQACgCAEAAQADAAADACQADADgBADIAAAcIAfAAQADAAACACQACADAAADQAAADgCACQgCACgDAAIgfAAIAABEQABAKAFAFQAFAFAJAAQAHAAAEgCQADAAACACQACACAAADQAAAFgEACQgJADgJAAQgHAAgGgCgAVkg9QgDgDAAgDIAAiVQAAgEADgCQACgDAEAAQADAAACADQADACAAAEIAACVQAAADgCADQgCACgEAAQgEAAgCgCgARPg9QgDgDABgDIAAhlQgBgEADgDQADgCADAAQAEAAACACQACADABAEIAABlQAAADgCADQgDACgEAAQgDAAgDgCgAPVg9QgDgDAAgDIAAhlQAAgEADgDQACgCADAAQAEAAADACQACADAAAEIAABlQAAADgCADQgCACgFAAQgDAAgCgCgAOGg9QgDgDAAgDIAAhlQAAgEADgDQACgCADAAQAEAAACACQADADAAAEIAAAVIAIgNQAEgFAGgEIALgHQAGgCAFAAQAEAAADADQACACAAAEQAAAIgIABQgIABgIAEQgHAEgGAGQgFAHgDAJQgEAKAAAMIAAAoQAAADgCADQgDACgEAAQgDAAgCgCgAFgg9QgDgDAAgDIAAg9QAAgIgCgGQgCgHgEgEQgEgFgGgCQgHgDgHAAQgIAAgGADQgGACgFAFQgFAFgCAHQgDAHAAAIIAAA7QAAADgCADQgDACgDAAQgEAAgDgCQgCgDAAgDIAAhlQAAgEACgDQADgCAEAAQADAAADACQACADAAAEIAAAMIAHgJQADgEAGgDQAEgDAHgCQAFgCAIAAQAKAAAJAEQAIADAGAGQAGAGADAJQACAJAAAKIAABBQAAADgCADQgDACgDAAQgDAAgDgCgADfg9QgCgDAAgDIAAhlQAAgEACgDQADgCADAAQAEAAADACQACADAAAEIAABlQAAADgCADQgDACgEAAQgDAAgDgCgAtmg9QgDgDAAgDIAAg9QAAgIgCgGQgCgHgEgEQgFgFgFgCQgGgDgIAAQgIAAgGADQgGACgFAFQgFAFgCAHQgDAHAAAIIAAA7QAAADgCADQgDACgEAAQgDAAgDgCQgCgDAAgDIAAhlQAAgEACgDQADgCADAAQAEAAADACQACADAAAEIAAAMIAHgJQAEgEAFgDQAFgDAFgCQAGgCAIAAQAKAAAJAEQAIADAGAGQAFAGADAJQADAJAAAKIAABBQAAADgCADQgDACgDAAQgDAAgDgCgAwIg9QgCgDAAgDIAAhlQAAgEACgDQADgCADAAQADAAADACQACADAAAEIAAAVIAIgNQAFgFAFgEIAMgHQAFgCAGAAQADAAADADQACACABAEQAAAIgJABQgIABgIAEQgHAEgFAGQgGAHgDAJQgEAKAAAMIAAAoQAAADgCADQgCACgEAAQgDAAgDgCgA1og8QgEAAgDgCQgCgDAAgEIAAiMQAAgEACgDQADgCAEAAQADAAADACQADADAAAEIAACFIBRAAQADAAADACQADADAAADQAAAEgDACQgDACgDAAgALFh2QgDAAgDgDQgDgDAAgDQAAgEADgDQADgCADAAIAwAAQADAAACACQAEADAAAEQAAADgEADQgCADgDAAgAROjLQgDgDAAgEIAAgDQAAgEADgCQADgDAEAAQAEAAAEADQACACAAAEIAAADQAAAEgCADQgEADgEAAQgEAAgDgDgAPTjLQgDgDAAgEIAAgDQAAgEADgCQADgDAEAAQAFAAADADQADACAAAEIAAADQAAAEgDADQgDADgFAAQgEAAgDgDgADejLQgDgDAAgEIAAgDQAAgEADgCQADgDAEAAQAFAAADADQADACAAAEIAAADQAAAEgDADQgDADgFAAQgEAAgDgDg");
	this.shape.setTransform(-5.7,29.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#133C7D").s().p("A5YGyQh7AAAAh7IAAptQAAh7B7AAMAyxAAAQB7AAAAB7IAAJtQAAB7h7AAg");
	this.shape_1.setTransform(-5.6,29.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(-180.4,-13.8,349.7,86.9), null);


(lib.circleFade2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_24 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(24).call(this.frame_24).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#009CDD").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape.setTransform(9,9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,156,221,0.8)").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape_1.setTransform(9,9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,156,221,0.6)").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape_2.setTransform(9,9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(0,156,221,0.4)").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape_3.setTransform(9,9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(0,156,221,0.2)").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape_4.setTransform(9,9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(0,156,221,0)").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape_5.setTransform(9,9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},19).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18,18);


(lib.circleFade = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_24 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(24).call(this.frame_24).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape.setTransform(9,9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.8)").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape_1.setTransform(9,9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.6)").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape_2.setTransform(9,9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.4)").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape_3.setTransform(9,9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.2)").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape_4.setTransform(9,9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0)").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape_5.setTransform(9,9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},19).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18,18);


(lib.circleColourMid = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#203D79").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape.setTransform(9,9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.circleColourMid, new cjs.Rectangle(0,0,18,18), null);


(lib.circleColour = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var ColourFrame = 0;
		this.gotoAndStop(ColourFrame);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(5));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#203D79").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape.setTransform(9,9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0F5191").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape_1.setTransform(9,9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#397FBA").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape_2.setTransform(9,9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#009CDD").s().p("Ag/BAQgagbAAglQAAgkAagbQAbgaAkAAQAlAAAbAaQAaAbAAAkQAAAlgaAbQgbAaglAAQgkAAgbgag");
	this.shape_3.setTransform(9,9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18,18);


(lib.nbnLayer1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_20 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(20).call(this.frame_20).wait(1));

	// circle1
	this.instance = new lib.circleColourMid();
	this.instance.parent = this;
	this.instance.setTransform(20,5.2,0.452,0.452,0,0,0,9,9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).wait(2));

	// circle1
	this.cc = new lib.circleColourMid();
	this.cc.parent = this;
	this.cc.setTransform(13.3,8.6,0.452,0.452,0,0,0,9,9);
	this.cc._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc).wait(18).to({_off:false},0).wait(3));

	// circle1
	this.cc_1 = new lib.circleColourMid();
	this.cc_1.parent = this;
	this.cc_1.setTransform(8.4,13.2,0.452,0.452,0,0,0,9,9);
	this.cc_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_1).wait(17).to({_off:false},0).wait(4));

	// circle1
	this.cc_2 = new lib.circleColourMid();
	this.cc_2.parent = this;
	this.cc_2.setTransform(5.6,19.5,0.452,0.452,0,0,0,9,9);
	this.cc_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_2).wait(16).to({_off:false},0).wait(5));

	// circle1
	this.cc_3 = new lib.circleColourMid();
	this.cc_3.parent = this;
	this.cc_3.setTransform(4.1,26.8,0.452,0.452,0,0,0,9,9);
	this.cc_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_3).wait(15).to({_off:false},0).wait(6));

	// circle1
	this.cc_4 = new lib.circleColourMid();
	this.cc_4.parent = this;
	this.cc_4.setTransform(5.6,34.1,0.452,0.452,0,0,0,9,9);
	this.cc_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_4).wait(14).to({_off:false},0).wait(7));

	// circle1
	this.cc_5 = new lib.circleColourMid();
	this.cc_5.parent = this;
	this.cc_5.setTransform(8.4,40.4,0.452,0.452,0,0,0,9,9);
	this.cc_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_5).wait(13).to({_off:false},0).wait(8));

	// circle1
	this.cc_6 = new lib.circleColourMid();
	this.cc_6.parent = this;
	this.cc_6.setTransform(13.7,45.3,0.452,0.452,0,0,0,9,9);
	this.cc_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_6).wait(12).to({_off:false},0).wait(9));

	// circle1
	this.cc_7 = new lib.circleColourMid();
	this.cc_7.parent = this;
	this.cc_7.setTransform(20,48.4,0.452,0.452,0,0,0,9,9);
	this.cc_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_7).wait(11).to({_off:false},0).wait(10));

	// circle1
	this.cc_8 = new lib.circleColourMid();
	this.cc_8.parent = this;
	this.cc_8.setTransform(26.8,49.6,0.452,0.452,0,0,0,9,9);
	this.cc_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_8).wait(10).to({_off:false},0).wait(11));

	// circle1
	this.cc_9 = new lib.circleColourMid();
	this.cc_9.parent = this;
	this.cc_9.setTransform(33.8,48.4,0.452,0.452,0,0,0,9,9);
	this.cc_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_9).wait(9).to({_off:false},0).wait(12));

	// circle1
	this.cc_10 = new lib.circleColourMid();
	this.cc_10.parent = this;
	this.cc_10.setTransform(39.9,45.3,0.452,0.452,0,0,0,9,9);
	this.cc_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_10).wait(8).to({_off:false},0).wait(13));

	// circle1
	this.cc_11 = new lib.circleColourMid();
	this.cc_11.parent = this;
	this.cc_11.setTransform(45.3,40.8,0.452,0.452,0,0,0,9,9);
	this.cc_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_11).wait(7).to({_off:false},0).wait(14));

	// circle1
	this.cc_12 = new lib.circleColourMid();
	this.cc_12.parent = this;
	this.cc_12.setTransform(48,34.1,0.452,0.452,0,0,0,9,9);
	this.cc_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_12).wait(6).to({_off:false},0).wait(15));

	// circle1
	this.cc_13 = new lib.circleColourMid();
	this.cc_13.parent = this;
	this.cc_13.setTransform(49.5,26.8,0.452,0.452,0,0,0,9,9);
	this.cc_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_13).wait(5).to({_off:false},0).wait(16));

	// circle1
	this.cc_14 = new lib.circleColourMid();
	this.cc_14.parent = this;
	this.cc_14.setTransform(48,19.5,0.452,0.452,0,0,0,9,9);
	this.cc_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_14).wait(4).to({_off:false},0).wait(17));

	// circle1
	this.cc_15 = new lib.circleColourMid();
	this.cc_15.parent = this;
	this.cc_15.setTransform(45.5,13.1,0.452,0.452,0,0,0,9,9);
	this.cc_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_15).wait(3).to({_off:false},0).wait(18));

	// circle1
	this.cc_16 = new lib.circleColourMid();
	this.cc_16.parent = this;
	this.cc_16.setTransform(40.1,8.6,0.452,0.452,0,0,0,9,9);
	this.cc_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_16).wait(2).to({_off:false},0).wait(19));

	// circle1
	this.cc_17 = new lib.circleColourMid();
	this.cc_17.parent = this;
	this.cc_17.setTransform(33.8,5.2,0.452,0.452,0,0,0,9,9);
	this.cc_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cc_17).wait(1).to({_off:false},0).wait(20));

	// circle1
	this.cc_18 = new lib.circleColourMid();
	this.cc_18.parent = this;
	this.cc_18.setTransform(26.8,4.1,0.452,0.452,0,0,0,9,9);

	this.timeline.addTween(cjs.Tween.get(this.cc_18).wait(21));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(22.8,0,8.1,8.2);


(lib.circle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// circleFade
	this.circleFade2 = new lib.circleFade2();
	this.circleFade2.parent = this;
	this.circleFade2.setTransform(9,9,1,1,0,0,0,9,9);
	this.circleFade2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.circleFade2).wait(1));

	// circleFade
	this.circleFade = new lib.circleFade();
	this.circleFade.parent = this;
	this.circleFade.setTransform(9,9,1,1,0,0,0,9,9);

	this.timeline.addTween(cjs.Tween.get(this.circleFade).wait(1));

	// CircleColour
	this.cc = new lib.circleColour();
	this.cc.parent = this;
	this.cc.setTransform(9,9,1,1,0,0,0,9,9);

	this.timeline.addTween(cjs.Tween.get(this.cc).wait(1));

}).prototype = getMCSymbolPrototype(lib.circle, new cjs.Rectangle(0,0,18,18), null);


(lib.NBNtrail = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//Variables
		var trailroot = this,
			coords = [],
			circleMovie,
			ranTime, x, y, ranScaleX, ranScaleY, ranAlpha, ranDelay,
			ranX, ranY, trailx, traily, ranXend, ranYend,
			bannerScale, particleAmount;
		
		
		initBanner();
		
		setTimeout(auroraAnimate,100);
		
		
		function initBanner(){
			// if scaling banner up
			// 1: 300x250
			// 2: 600x500
			bannerScale = 1;
		
			
			ColourFrame = 0;
			particleAmount = 85;
			storeEndCoordinate(0, 0, 0, 0, coords);
		
			//storing end circle coordinates for later use
			for (var i = 1; i <= particleAmount; i++) {
				//console.log(i);
				circleMovie = eval("trailroot.circle"+i);
				storeEndCoordinate(circleMovie.x, circleMovie.y, circleMovie.scaleX, circleMovie.scaleY, coords);
				circleMovie.x = -1000;
				circleMovie.y = -1000;
				
				circleColour = eval("trailroot.circle"+i+".cc");
				ColourFrame = Math.round(Math.random()*5)-1;
				//checkColour(i, circleColour);
				circleColour.gotoAndStop(ColourFrame);
			}
		}
		
		
		
		function storeEndCoordinate(xVal, yVal, xscaleVal, yscaleVal, array) {
		    array.push({x: xVal, y: yVal, xscale: xscaleVal, yscale: yscaleVal});
		}
		
		
		function auroraAnimate() {
			
			for (var i = 1; i <= particleAmount; i++) {
				//initial properties
				
				circleMovie = eval("trailroot.circle"+i);
				circleMovie.x = coords[i].x;
				circleMovie.y = coords[i].y;
				circleMovie.scaleX = coords[i].xscale;
				circleMovie.scaleY = coords[i].yscale;
				
				circleMovie.alpha = Math.random()*0.35+0.35;
				
				//end properties
				ranTime = 0.6 + (Math.random()*0.3) - i*0.005;
				ranDelay = i*0.03 - (Math.random()*0.1);
				
				trailx = coords[i].x;
				traily = coords[i].y;
				
				ranX = (trailx - Math.random()*50) * bannerScale;
				ranY = (traily + Math.random()*30-15) * bannerScale;
				
				ranXend = (trailx + Math.random()*1) * bannerScale;
				ranYend = (traily + Math.random()*10) * bannerScale;
				
				ranScaleX = ranScaleY = (Math.random()*0.1+0.1) * bannerScale;
				ranAlpha = 0;
				
				TweenMax.from(circleMovie, ranTime, {x:ranX, y:ranY, scaleX:ranScaleX, scaleY:ranScaleY, alpha:ranAlpha, 
											delay:ranDelay, ease:Sine.easeOut,
											onComplete:objFadeOut, onCompleteParams:[circleMovie, ranXend, ranYend]});
				
				
											
				circleFadeMovie = eval("trailroot.circle"+i+".circleFade");
				circleFadeMovie.alpha = Math.random()*0.5 + Math.round(Math.random()*1) - i*0.015;
				circleFadeMovie.stop();
			}
			
		}
		
		function objFadeOut(circleMovie, ranXend, ranYend){
			
			TweenMax.to(circleMovie, 0.4, {x:ranXend, y:ranYend, scaleX:0.1, scaleY:0.1, alpha:0, ease:Sine.easeInOut});
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// trail
	this.circle84 = new lib.circle();
	this.circle84.parent = this;
	this.circle84.setTransform(-70.7,54.9,0.2,0.2,0,0,0,9.2,10);

	this.circle85 = new lib.circle();
	this.circle85.parent = this;
	this.circle85.setTransform(-60,13.4,0.153,0.153,0,0,0,9.2,9.5);

	this.circle82 = new lib.circle();
	this.circle82.parent = this;
	this.circle82.setTransform(-62.8,43.5,0.105,0.105,0,0,0,9.1,9.6);

	this.circle83 = new lib.circle();
	this.circle83.parent = this;
	this.circle83.setTransform(-49.6,32.9,0.114,0.114,0,0,0,9.2,9.7);

	this.circle81 = new lib.circle();
	this.circle81.parent = this;
	this.circle81.setTransform(-50.2,6,0.14,0.14,0,0,0,9,10.4);

	this.circle80 = new lib.circle();
	this.circle80.parent = this;
	this.circle80.setTransform(-62.9,32.8,0.102,0.102,0,0,0,8.8,10.3);

	this.circle75 = new lib.circle();
	this.circle75.parent = this;
	this.circle75.setTransform(-69.7,41.7,0.246,0.246,0,0,0,9.6,9.6);

	this.circle79 = new lib.circle();
	this.circle79.parent = this;
	this.circle79.setTransform(-72.8,35,0.207,0.207,0,0,0,9.2,9.9);

	this.circle78 = new lib.circle();
	this.circle78.parent = this;
	this.circle78.setTransform(-81.8,44.7,0.153,0.153,0,0,0,9.2,9.5);

	this.circle76 = new lib.circle();
	this.circle76.parent = this;
	this.circle76.setTransform(-64.7,22.8,0.295,0.295,0,0,0,9.3,9.7);

	this.circle77 = new lib.circle();
	this.circle77.parent = this;
	this.circle77.setTransform(-74.1,29.4,0.194,0.194,0,0,0,9.5,9.8);

	this.circle74 = new lib.circle();
	this.circle74.parent = this;
	this.circle74.setTransform(-53.5,7.9,0.153,0.153,0,0,0,9.2,9.5);

	this.circle73 = new lib.circle();
	this.circle73.parent = this;
	this.circle73.setTransform(-68.3,33.4,0.247,0.247,0,0,0,9.6,10.2);

	this.circle72 = new lib.circle();
	this.circle72.parent = this;
	this.circle72.setTransform(-67.1,28,0.266,0.266,0,0,0,9.2,9.8);

	this.circle71 = new lib.circle();
	this.circle71.parent = this;
	this.circle71.setTransform(-50.9,13.7,0.268,0.268,0,0,0,9.5,9.5);

	this.circle70 = new lib.circle();
	this.circle70.parent = this;
	this.circle70.setTransform(-74.2,29.7,0.221,0.221,0,0,0,9.5,9.5);

	this.circle69 = new lib.circle();
	this.circle69.parent = this;
	this.circle69.setTransform(-61.6,24.2,0.298,0.298,0,0,0,9.4,9.6);

	this.circle66 = new lib.circle();
	this.circle66.parent = this;
	this.circle66.setTransform(-81.2,33.9,0.248,0.248,0,0,0,9.2,9.8);

	this.circle67 = new lib.circle();
	this.circle67.parent = this;
	this.circle67.setTransform(-80,20.2,0.153,0.153,0,0,0,9.2,9.5);

	this.circle65 = new lib.circle();
	this.circle65.parent = this;
	this.circle65.setTransform(-102,37.7,0.306,0.306,0,0,0,9.2,10);

	this.circle68 = new lib.circle();
	this.circle68.parent = this;
	this.circle68.setTransform(-70.5,21.4,0.153,0.153,0,0,0,9.2,9.5);

	this.circle64 = new lib.circle();
	this.circle64.parent = this;
	this.circle64.setTransform(-94.1,40.5,0.256,0.256,0,0,0,9.2,9.8);

	this.circle63 = new lib.circle();
	this.circle63.parent = this;
	this.circle63.setTransform(-59,18.4,0.239,0.239,0,0,0,9.2,10.1);

	this.circle60 = new lib.circle();
	this.circle60.parent = this;
	this.circle60.setTransform(-69.8,25.2,0.254,0.254,0,0,0,9.5,9.8);

	this.circle62 = new lib.circle();
	this.circle62.parent = this;
	this.circle62.setTransform(-79.1,28.9,0.285,0.285,0,0,0,9.3,9.7);

	this.circle58 = new lib.circle();
	this.circle58.parent = this;
	this.circle58.setTransform(-71.2,19.6,0.153,0.153,0,0,0,9.2,9.5);

	this.circle59 = new lib.circle();
	this.circle59.parent = this;
	this.circle59.setTransform(-72.2,26,0.311,0.311,0,0,0,9.5,9.8);

	this.circle61 = new lib.circle();
	this.circle61.parent = this;
	this.circle61.setTransform(-66,16.5,0.181,0.181,0,0,0,9.2,10);

	this.circle57 = new lib.circle();
	this.circle57.parent = this;
	this.circle57.setTransform(-83.8,21.8,0.247,0.247,0,0,0,9.5,9.7);

	this.circle56 = new lib.circle();
	this.circle56.parent = this;
	this.circle56.setTransform(-85.9,32,0.334,0.334,0,0,0,9.4,10);

	this.circle55 = new lib.circle();
	this.circle55.parent = this;
	this.circle55.setTransform(-97.6,22,0.238,0.238,0,0,0,9.5,9.7);

	this.circle54 = new lib.circle();
	this.circle54.parent = this;
	this.circle54.setTransform(-95.9,30,0.289,0.289,0,0,0,9.3,9.7);

	this.circle53 = new lib.circle();
	this.circle53.parent = this;
	this.circle53.setTransform(-82.4,31.4,0.252,0.252,0,0,0,9.2,10);

	this.circle52 = new lib.circle();
	this.circle52.parent = this;
	this.circle52.setTransform(-63.8,7.1,0.153,0.153,0,0,0,9.2,9.5);

	this.circle51 = new lib.circle();
	this.circle51.parent = this;
	this.circle51.setTransform(-75.7,43.8,0.2,0.2,0,0,0,9,9.2);

	this.circle50 = new lib.circle();
	this.circle50.parent = this;
	this.circle50.setTransform(-76.3,36,0.2,0.2,0,0,0,9,9.2);

	this.circle49 = new lib.circle();
	this.circle49.parent = this;
	this.circle49.setTransform(-91.8,31.7,0.341,0.341,0,0,0,9.1,9.4);

	this.circle48 = new lib.circle();
	this.circle48.parent = this;
	this.circle48.setTransform(-90.8,38.1,0.342,0.342,0,0,0,9.1,9.7);

	this.circle40 = new lib.circle();
	this.circle40.parent = this;
	this.circle40.setTransform(-115.7,26.8,0.2,0.2,0,0,0,9,9.2);

	this.circle45 = new lib.circle();
	this.circle45.parent = this;
	this.circle45.setTransform(-107.9,33.2,0.228,0.228,0,0,0,9,9.4);

	this.circle47 = new lib.circle();
	this.circle47.parent = this;
	this.circle47.setTransform(-83.5,36.5,0.226,0.226,0,0,0,8.8,9.5);

	this.circle43 = new lib.circle();
	this.circle43.parent = this;
	this.circle43.setTransform(-96.5,38.6,0.269,0.269,0,0,0,9.1,9.3);

	this.circle46 = new lib.circle();
	this.circle46.parent = this;
	this.circle46.setTransform(-102.4,31.6,0.394,0.394,0,0,0,9.2,9.4);

	this.circle41 = new lib.circle();
	this.circle41.parent = this;
	this.circle41.setTransform(-113,29.4,0.286,0.286,0,0,0,9.2,9.6);

	this.circle44 = new lib.circle();
	this.circle44.parent = this;
	this.circle44.setTransform(-99.7,34.6,0.325,0.325,0,0,0,9.1,9.2);

	this.circle42 = new lib.circle();
	this.circle42.parent = this;
	this.circle42.setTransform(-110,34.3,0.355,0.355,0,0,0,9.2,9.3);

	this.circle39 = new lib.circle();
	this.circle39.parent = this;
	this.circle39.setTransform(-119.4,29.2,0.375,0.375,0,0,0,9.3,9.5);

	this.circle38 = new lib.circle();
	this.circle38.parent = this;
	this.circle38.setTransform(-122.7,23.3,0.316,0.316,0,0,0,9,9.3);

	this.circle34 = new lib.circle();
	this.circle34.parent = this;
	this.circle34.setTransform(-131,26,0.344,0.344,0,0,0,9.2,9.3);

	this.circle36 = new lib.circle();
	this.circle36.parent = this;
	this.circle36.setTransform(-125.5,22.1,0.339,0.339,0,0,0,9.2,9.3);

	this.circle37 = new lib.circle();
	this.circle37.parent = this;
	this.circle37.setTransform(-114.5,38.8,0.211,0.211,0,0,0,9,9.2);

	this.circle35 = new lib.circle();
	this.circle35.parent = this;
	this.circle35.setTransform(-114.4,18.6,0.2,0.2,0,0,0,9,9.2);

	this.circle33 = new lib.circle();
	this.circle33.parent = this;
	this.circle33.setTransform(-138.7,33.2,0.2,0.2,0,0,0,9,9.2);

	this.circle30 = new lib.circle();
	this.circle30.parent = this;
	this.circle30.setTransform(-131.4,19.7,0.306,0.306,0,0,0,9,9.3);

	this.circle31 = new lib.circle();
	this.circle31.parent = this;
	this.circle31.setTransform(-128.3,16.7,0.306,0.306,0,0,0,9,9.3);

	this.circle32 = new lib.circle();
	this.circle32.parent = this;
	this.circle32.setTransform(-137.3,20.1,0.489,0.489,0,0,0,9,9.3);

	this.circle28 = new lib.circle();
	this.circle28.parent = this;
	this.circle28.setTransform(-145.3,27,0.27,0.27,0,0,0,9.1,9.5);

	this.circle29 = new lib.circle();
	this.circle29.parent = this;
	this.circle29.setTransform(-142.9,17.9,0.336,0.336,0,0,0,9.1,9.3);

	this.circle27 = new lib.circle();
	this.circle27.parent = this;
	this.circle27.setTransform(-152.6,18.9,0.221,0.221,0,0,0,9.1,9.3);

	this.circle25 = new lib.circle();
	this.circle25.parent = this;
	this.circle25.setTransform(-149.1,14.2,0.499,0.499,0,0,0,9.1,9.5);

	this.circle23 = new lib.circle();
	this.circle23.parent = this;
	this.circle23.setTransform(-156.6,18.3,0.112,0.112,0,0,0,9,9.4);

	this.circle26 = new lib.circle();
	this.circle26.parent = this;
	this.circle26.setTransform(-140.2,12.9,0.306,0.306,0,0,0,9,9.3);

	this.circle21 = new lib.circle();
	this.circle21.parent = this;
	this.circle21.setTransform(-161.9,9,0.487,0.487,0,0,0,9.1,9.6);

	this.circle24 = new lib.circle();
	this.circle24.parent = this;
	this.circle24.setTransform(-155.9,9.1,0.492,0.492,0,0,0,9.2,9.5);

	this.circle22 = new lib.circle();
	this.circle22.parent = this;
	this.circle22.setTransform(-154.1,9.7,0.219,0.219,0,0,0,9.2,9.3);

	this.circle18 = new lib.circle();
	this.circle18.parent = this;
	this.circle18.setTransform(-164.5,19.4,0.306,0.306,0,0,0,9,9.3);

	this.circle20 = new lib.circle();
	this.circle20.parent = this;
	this.circle20.setTransform(-154.7,16.7,0.187,0.187,0,0,0,9.1,9.3);

	this.circle19 = new lib.circle();
	this.circle19.parent = this;
	this.circle19.setTransform(-166.9,10.4,0.306,0.306,0,0,0,9,9.3);

	this.circle17 = new lib.circle();
	this.circle17.parent = this;
	this.circle17.setTransform(-169.4,13.8,0.306,0.306,0,0,0,9,9.3);

	this.circle16 = new lib.circle();
	this.circle16.parent = this;
	this.circle16.setTransform(-182.9,15.3,0.36,0.36,0,0,0,9.1,9.6);

	this.circle1 = new lib.circle();
	this.circle1.parent = this;
	this.circle1.setTransform(-202.5,13.4,0.205,0.205,0,0,0,8.8,9);

	this.circle10 = new lib.circle();
	this.circle10.parent = this;
	this.circle10.setTransform(-170.6,24,0.17,0.17,0,0,0,9.1,9.4);

	this.circle15 = new lib.circle();
	this.circle15.parent = this;
	this.circle15.setTransform(-174.7,14,0.49,0.49,0,0,0,9.1,9.4);

	this.circle14 = new lib.circle();
	this.circle14.parent = this;
	this.circle14.setTransform(-168.9,2,0.28,0.28,0,0,0,8.9,9.2);

	this.circle13 = new lib.circle();
	this.circle13.parent = this;
	this.circle13.setTransform(-173.6,22.7,0.28,0.28,0,0,0,8.9,9.2);

	this.circle12 = new lib.circle();
	this.circle12.parent = this;
	this.circle12.setTransform(-179.4,18.6,0.367,0.367,0,0,0,9,9.2);

	this.circle9 = new lib.circle();
	this.circle9.parent = this;
	this.circle9.setTransform(-186.2,19,0.126,0.126,0,0,0,9.1,9.5);

	this.circle11 = new lib.circle();
	this.circle11.parent = this;
	this.circle11.setTransform(-195.2,6.1,0.28,0.28,0,0,0,8.9,9.2);

	this.circle3 = new lib.circle();
	this.circle3.parent = this;
	this.circle3.setTransform(-189.1,28.4,0.302,0.302,0,0,0,9.1,9.2);

	this.circle7 = new lib.circle();
	this.circle7.parent = this;
	this.circle7.setTransform(-185.7,21.4,0.28,0.28,0,0,0,8.9,9.2);

	this.circle5 = new lib.circle();
	this.circle5.parent = this;
	this.circle5.setTransform(-192.2,24.3,0.383,0.383,0,0,0,9.2,9.2);

	this.circle6 = new lib.circle();
	this.circle6.parent = this;
	this.circle6.setTransform(-187.8,19.4,0.371,0.371,0,0,0,8.8,9.3);

	this.circle4 = new lib.circle();
	this.circle4.parent = this;
	this.circle4.setTransform(-198.5,24.9,0.417,0.417,0,0,0,8.9,9.5);

	this.circle8 = new lib.circle();
	this.circle8.parent = this;
	this.circle8.setTransform(-194.4,19.7,0.28,0.28,0,0,0,8.9,9.2);

	this.circle2 = new lib.circle();
	this.circle2.parent = this;
	this.circle2.setTransform(-203,27.5,0.139,0.139,0,0,0,9,9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.circle2},{t:this.circle8},{t:this.circle4},{t:this.circle6},{t:this.circle5},{t:this.circle7},{t:this.circle3},{t:this.circle11},{t:this.circle9},{t:this.circle12},{t:this.circle13},{t:this.circle14},{t:this.circle15},{t:this.circle10},{t:this.circle1},{t:this.circle16},{t:this.circle17},{t:this.circle19},{t:this.circle20},{t:this.circle18},{t:this.circle22},{t:this.circle24},{t:this.circle21},{t:this.circle26},{t:this.circle23},{t:this.circle25},{t:this.circle27},{t:this.circle29},{t:this.circle28},{t:this.circle32},{t:this.circle31},{t:this.circle30},{t:this.circle33},{t:this.circle35},{t:this.circle37},{t:this.circle36},{t:this.circle34},{t:this.circle38},{t:this.circle39},{t:this.circle42},{t:this.circle44},{t:this.circle41},{t:this.circle46},{t:this.circle43},{t:this.circle47},{t:this.circle45},{t:this.circle40},{t:this.circle48},{t:this.circle49},{t:this.circle50},{t:this.circle51},{t:this.circle52},{t:this.circle53},{t:this.circle54},{t:this.circle55},{t:this.circle56},{t:this.circle57},{t:this.circle61},{t:this.circle59},{t:this.circle58},{t:this.circle62},{t:this.circle60},{t:this.circle63},{t:this.circle64},{t:this.circle68},{t:this.circle65},{t:this.circle67},{t:this.circle66},{t:this.circle69},{t:this.circle70},{t:this.circle71},{t:this.circle72},{t:this.circle73},{t:this.circle74},{t:this.circle77},{t:this.circle76},{t:this.circle78},{t:this.circle79},{t:this.circle75},{t:this.circle80},{t:this.circle81},{t:this.circle83},{t:this.circle82},{t:this.circle85},{t:this.circle84}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.NBNtrail, new cjs.Rectangle(-204.3,-0.6,163.2,62.6), null);


(lib.nbnMid = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var root = this;
		
		this.stop();
		
		setTimeout(playMid, 2000);
		
		function playMid(){
			root.gotoAndPlay(1);
		}
	}
	this.frame_19 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(1));

	// mid
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#223D79").s().p("AgPAQQgHgHAAgJQAAgJAHgGQAGgHAJAAQAJAAAHAHQAHAGAAAJQAAAKgHAGQgGAHgKAAQgJAAgGgHg");
	this.shape.setTransform(27.3,26.5,1.732,1.732);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#223D79").s().p("AgjAkQgPgQAAgUQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAWgPAOQgOAPgWAAQgUAAgPgPg");
	this.shape_1.setTransform(27.3,26.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#223D79").s().p("AgqArQgTgSAAgZQAAgZATgRQARgTAZAAQAZAAATATQASARAAAZQAAAagSARQgSATgaAAQgZAAgRgTg");
	this.shape_2.setTransform(27.2,26.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#223D79").s().p("AgxAyQgWgVAAgdQAAgdAWgUQAUgWAdAAQAdAAAVAWQAWAUAAAdQAAAfgWATQgUAWgeAAQgdAAgUgWg");
	this.shape_3.setTransform(27.2,26.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#223D79").s().p("Ag4A5QgYgYgBghQABghAYgXQAWgZAiAAQAgAAAZAZQAZAXgBAhQABAjgZAWQgXAZgiAAQgiAAgWgZg");
	this.shape_4.setTransform(27.2,26.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#223D79").s().p("Ag+A/QgbgbAAgkQAAglAbgZQAZgbAlAAQAkAAAbAbQAbAZAAAlQAAAmgbAZQgZAbgmAAQglAAgZgbg");
	this.shape_5.setTransform(27.1,26.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#223D79").s().p("AhEBFQgdgeAAgnQAAgoAdgbQAcgeAoAAQAnAAAeAeQAdAbAAAoQAAApgdAcQgcAdgpAAQgoAAgcgdg");
	this.shape_6.setTransform(27.1,26.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#223D79").s().p("AhJBKQggggAAgqQAAgrAggeQAdggAsAAQAqAAAgAgQAgAeAAArQAAAsggAeQgeAggsAAQgsAAgdggg");
	this.shape_7.setTransform(27.1,26.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#223D79").s().p("AhOBPQghgjAAgsQAAguAhggQAfghAvAAQAtAAAiAhQAhAgABAuQgBAvghAgQggAhgvABQgvgBgfghg");
	this.shape_8.setTransform(27.1,26.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#223D79").s().p("AhSBTQgkgkAAgvQAAgxAkggQAhglAxABQAvgBAkAlQAkAgAAAxQAAAygkAhQghAjgyAAQgxAAghgjg");
	this.shape_9.setTransform(27,26.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#223D79").s().p("AhWBXQglgmAAgxQAAgzAlgjQAjglAyAAQAyAAAmAlQAlAjAAAzQAAA0glAjQgjAlg1AAQgyAAgjglg");
	this.shape_10.setTransform(27,26.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#223D79").s().p("AhZBaQgngnAAgzQAAg1AngkQAkgnA1AAQA0AAAmAnQAnAkAAA1QAAA2gnAkQgkAng2AAQg1AAgkgng");
	this.shape_11.setTransform(27,26.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#223D79").s().p("AhcBdQgogoAAg1QAAg3AoglQAlgoA2AAQA2AAAoAoQAoAlAAA3QAAA4goAlQglAog5AAQg2AAglgog");
	this.shape_12.setTransform(27,26.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#223D79").s().p("AhfBgQgpgqABg2QgBg4ApgmQAngqA4AAQA3AAApAqQApAmgBA4QABA5gpAnQgnApg5AAQg4AAgngpg");
	this.shape_13.setTransform(27,26.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#223D79").s().p("AhhBiQgqgqAAg4QAAg6AqgmQAogrA4AAQA4AAArArQApAmAAA6QAAA7gpAnQgnAqg8AAQg4AAgogqg");
	this.shape_14.setTransform(27,26.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#223D79").s().p("AhiBjQgrgqAAg5QAAg7ArgnQAogrA5AAQA6AAAqArQArAnAAA7QAAA7grAoQgnArg9AAQg5AAgogrg");
	this.shape_15.setTransform(26.9,26.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#223D79").s().p("AhjBkQgrgrgBg5QABg7ArgoQAogrA6AAQA6AAArArQAsAoAAA7QAAA8gsAoQgoArg9AAQg6AAgogrg");
	this.shape_16.setTransform(27,26.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#223D79").s().p("AhkBlQgrgrAAg6QAAg8ArgoQAogrA7AAQA7AAArArQArAoAAA8QAAA9grAoQgoArg+AAQg7AAgogrg");
	this.shape_17.setTransform(26.9,26.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape,p:{scaleX:1.732,scaleY:1.732,x:27.3,y:26.5}}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape,p:{scaleX:6.227,scaleY:6.227,x:26.9,y:26.6}}]},1).wait(1));

	// Layer 4
	this.instance = new lib.nbnLayer1();
	this.instance.parent = this;
	this.instance.setTransform(26.6,26.8,0.133,0.133,-90,0,0,26.8,27.2);
	this.instance.alpha = 0.422;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regY:26.8,scaleX:1,scaleY:1,rotation:0,alpha:1},18,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.NBNlogo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//Variables
		var root = this,
			coords = [],
			circleMovie,
			ranTime, x, y, ranScaleX, ranScaleY, ranAlpha, ranDelay,
			ranX, ranY, nbnMidX, nbnMidY,
			bannerScale, particleAmount;
		
		
		initBanner();
		
		setTimeout(auroraAnimate,1500);
		
		function initBanner(){
			// if scaling banner up
			// 1: 300x250
			// 2: 600x500
			bannerScale = 1;
			
			
			ColourFrame = 0;
			particleAmount = 104;
			storeEndCoordinate(0, 0, 0, 0, coords);
		
			//storing end circle coordinates for later use
			for (var i = 1; i <= particleAmount; i++) {
				//console.log(i);
				circleMovie = eval("root.circle"+i);
				storeEndCoordinate(circleMovie.x, circleMovie.y, circleMovie.scaleX, circleMovie.scaleY, coords);
				circleMovie.x = -1000;
				circleMovie.y = -1000;
				
				circleColour = eval("root.circle"+i+".cc");
				checkColour(i, circleColour);
				circleColour.gotoAndStop(ColourFrame);
				
		
			}
		}
		
		function storeEndCoordinate(xVal, yVal, xscaleVal, yscaleVal, array) {
		    array.push({x: xVal, y: yVal, xscale: xscaleVal, yscale: yscaleVal});
		}
		
		function checkColour(i,circleColour)
		{
			if(i <= 36 && i >= 1)
			{
				ColourFrame = 1;
			}
			else if(i <= 62 && i >= 37)
			{
				ColourFrame = 2;
			}
			else if(i <= 82 && i >= 63)
			{
				ColourFrame = 3;
			}
			else if(i <= 104 && i >= 83)
			{
				ColourFrame = 4;
			}
		}
		
		function auroraAnimate() {
			
			for (var i = 1; i <= particleAmount; i++) {
				//initial properties
				
				circleMovie = eval("root.circle"+i);
				circleMovie.x = coords[i].x;
				circleMovie.y = coords[i].y;
				circleMovie.scaleX = coords[i].xscale;
				circleMovie.scaleY = coords[i].yscale;
				
				circleMovie.alpha = 1;
				
				//end properties
				ranTime = 1.5 + (Math.random()*0.5);
				ranDelay = 0.1 + (Math.random()*0.5);
				
				nbnMidX = root.nbnMid.x;
				nbnMidY = root.nbnMid.y;
				
				ranX = (nbnMidX -25 + Math.random()*50) * bannerScale;
				ranY = (nbnMidY -25 + Math.random()*50) * bannerScale;
				
				ranScaleX = ranScaleY = (Math.random()*0.5+0.1) * bannerScale;
				ranAlpha = 0;
				
				TweenMax.from(circleMovie, ranTime, {x:ranX, y:ranY, scaleX:ranScaleX, scaleY:ranScaleY, alpha:ranAlpha, 
											delay:ranDelay, ease:Expo.easeOut});
				
				circleFadeMovie = eval("root.circle"+i+".circleFade");
				circleFadeMovie.alpha = Math.random()*0.5 + Math.round(Math.random()*0.5);
				circleFadeMovie.play();
				
				circleFadeMovie2 = eval("root.circle"+i+".circleFade2");
				circleFadeMovie2.alpha = Math.random()*0.5 + Math.round(Math.random()*1);
				circleFadeMovie2.play();
			}
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// circle
	this.circle104 = new lib.circle();
	this.circle104.parent = this;
	this.circle104.setTransform(106,130.1,0.207,0.207,0,0,0,9.4,9.9);

	this.circle103 = new lib.circle();
	this.circle103.parent = this;
	this.circle103.setTransform(101.3,124,0.207,0.207,0,0,0,9.4,9.9);

	this.circle102 = new lib.circle();
	this.circle102.parent = this;
	this.circle102.setTransform(108.8,124.2,0.207,0.207,0,0,0,9.4,9.9);

	this.circle101 = new lib.circle();
	this.circle101.parent = this;
	this.circle101.setTransform(110.3,110.8,0.207,0.207,0,0,0,9.4,9.9);

	this.circle100 = new lib.circle();
	this.circle100.parent = this;
	this.circle100.setTransform(119,101.8,0.207,0.207,0,0,0,9.4,9.9);

	this.circle99 = new lib.circle();
	this.circle99.parent = this;
	this.circle99.setTransform(126.3,91.4,0.207,0.207,0,0,0,9.4,9.9);

	this.circle98 = new lib.circle();
	this.circle98.parent = this;
	this.circle98.setTransform(131.2,80.6,0.207,0.207,0,0,0,9.4,9.9);

	this.circle97 = new lib.circle();
	this.circle97.parent = this;
	this.circle97.setTransform(3.5,45.8,0.274,0.274,0,0,0,9.1,9.8);

	this.circle96 = new lib.circle();
	this.circle96.parent = this;
	this.circle96.setTransform(2.5,56.7,0.274,0.274,0,0,0,9.1,9.8);

	this.circle95 = new lib.circle();
	this.circle95.parent = this;
	this.circle95.setTransform(3.5,67.5,0.274,0.274,0,0,0,9.1,9.8);

	this.circle94 = new lib.circle();
	this.circle94.parent = this;
	this.circle94.setTransform(6.3,77.9,0.274,0.274,0,0,0,9.1,9.8);

	this.circle93 = new lib.circle();
	this.circle93.parent = this;
	this.circle93.setTransform(11,87.8,0.274,0.274,0,0,0,9.1,9.8);

	this.circle92 = new lib.circle();
	this.circle92.parent = this;
	this.circle92.setTransform(17.1,96.7,0.274,0.274,0,0,0,9.1,9.8);

	this.circle91 = new lib.circle();
	this.circle91.parent = this;
	this.circle91.setTransform(96.1,110.5,0.288,0.288,0,0,0,9.1,9.9);

	this.circle90 = new lib.circle();
	this.circle90.parent = this;
	this.circle90.setTransform(104.8,104.4,0.288,0.288,0,0,0,9.1,9.9);

	this.circle89 = new lib.circle();
	this.circle89.parent = this;
	this.circle89.setTransform(112.8,96.8,0.288,0.288,0,0,0,9.1,9.9);

	this.circle88 = new lib.circle();
	this.circle88.parent = this;
	this.circle88.setTransform(119.1,87.9,0.288,0.288,0,0,0,9.1,9.9);

	this.circle87 = new lib.circle();
	this.circle87.parent = this;
	this.circle87.setTransform(123.3,77.8,0.288,0.288,0,0,0,9.1,9.9);

	this.circle86 = new lib.circle();
	this.circle86.parent = this;
	this.circle86.setTransform(126.4,67.5,0.288,0.288,0,0,0,9.1,9.9);

	this.circle85 = new lib.circle();
	this.circle85.parent = this;
	this.circle85.setTransform(127.2,56.9,0.288,0.288,0,0,0,9.1,9.9);

	this.circle84 = new lib.circle();
	this.circle84.parent = this;
	this.circle84.setTransform(104.8,9.1,0.288,0.288,0,0,0,9.1,9.9);

	this.circle83 = new lib.circle();
	this.circle83.parent = this;
	this.circle83.setTransform(96.3,2.9,0.288,0.288,0,0,0,9.1,9.9);

	this.circle82 = new lib.circle();
	this.circle82.parent = this;
	this.circle82.setTransform(15.3,38.8,0.352,0.352,0,0,0,9.1,9.8);

	this.circle81 = new lib.circle();
	this.circle81.parent = this;
	this.circle81.setTransform(12.8,47.5,0.352,0.352,0,0,0,9.1,9.8);

	this.circle80 = new lib.circle();
	this.circle80.parent = this;
	this.circle80.setTransform(12.2,56.7,0.352,0.352,0,0,0,9.1,9.8);

	this.circle79 = new lib.circle();
	this.circle79.parent = this;
	this.circle79.setTransform(12.8,65.8,0.352,0.352,0,0,0,9.1,9.8);

	this.circle78 = new lib.circle();
	this.circle78.parent = this;
	this.circle78.setTransform(15.3,74.9,0.352,0.352,0,0,0,9.1,9.8);

	this.circle77 = new lib.circle();
	this.circle77.parent = this;
	this.circle77.setTransform(19.1,83.1,0.352,0.352,0,0,0,9.1,9.8);

	this.circle76 = new lib.circle();
	this.circle76.parent = this;
	this.circle76.setTransform(24.5,90.7,0.352,0.352,0,0,0,9.1,9.8);

	this.circle75 = new lib.circle();
	this.circle75.parent = this;
	this.circle75.setTransform(91.3,102.6,0.352,0.352,0,0,0,9.1,9.8);

	this.circle74 = new lib.circle();
	this.circle74.parent = this;
	this.circle74.setTransform(98.8,97.2,0.352,0.352,0,0,0,9.1,9.8);

	this.circle73 = new lib.circle();
	this.circle73.parent = this;
	this.circle73.setTransform(105.2,90.6,0.352,0.352,0,0,0,9.1,9.8);

	this.circle72 = new lib.circle();
	this.circle72.parent = this;
	this.circle72.setTransform(110.6,83.1,0.352,0.352,0,0,0,9.1,9.8);

	this.circle71 = new lib.circle();
	this.circle71.parent = this;
	this.circle71.setTransform(114.6,74.9,0.352,0.352,0,0,0,9.1,9.8);

	this.circle70 = new lib.circle();
	this.circle70.parent = this;
	this.circle70.setTransform(116.7,65.8,0.352,0.352,0,0,0,9.1,9.8);

	this.circle69 = new lib.circle();
	this.circle69.parent = this;
	this.circle69.setTransform(117.7,56.7,0.352,0.352,0,0,0,9.1,9.8);

	this.circle68 = new lib.circle();
	this.circle68.parent = this;
	this.circle68.setTransform(116.7,47.5,0.352,0.352,0,0,0,9.1,9.8);

	this.circle67 = new lib.circle();
	this.circle67.parent = this;
	this.circle67.setTransform(114.6,38.8,0.352,0.352,0,0,0,9.1,9.8);

	this.circle66 = new lib.circle();
	this.circle66.parent = this;
	this.circle66.setTransform(110.6,30.3,0.352,0.352,0,0,0,9.1,9.8);

	this.circle65 = new lib.circle();
	this.circle65.parent = this;
	this.circle65.setTransform(105.2,22.9,0.352,0.352,0,0,0,9.1,9.8);

	this.circle64 = new lib.circle();
	this.circle64.parent = this;
	this.circle64.setTransform(98.7,16.3,0.352,0.352,0,0,0,9.1,9.8);

	this.circle63 = new lib.circle();
	this.circle63.parent = this;
	this.circle63.setTransform(91.3,11,0.352,0.352,0,0,0,9.1,9.8);

	this.circle62 = new lib.circle();
	this.circle62.parent = this;
	this.circle62.setTransform(31.7,28.9,0.4,0.4,0,0,0,9,9.8);

	this.circle61 = new lib.circle();
	this.circle61.parent = this;
	this.circle61.setTransform(27.5,35.1,0.4,0.4,0,0,0,9,9.8);

	this.circle60 = new lib.circle();
	this.circle60.parent = this;
	this.circle60.setTransform(24.3,41.9,0.4,0.4,0,0,0,9,9.8);

	this.circle59 = new lib.circle();
	this.circle59.parent = this;
	this.circle59.setTransform(22.3,49.1,0.4,0.4,0,0,0,9,9.8);

	this.circle58 = new lib.circle();
	this.circle58.parent = this;
	this.circle58.setTransform(21.7,56.7,0.4,0.4,0,0,0,9,9.8);

	this.circle57 = new lib.circle();
	this.circle57.parent = this;
	this.circle57.setTransform(22.3,64.2,0.4,0.4,0,0,0,9,9.8);

	this.circle56 = new lib.circle();
	this.circle56.parent = this;
	this.circle56.setTransform(24.3,71.5,0.4,0.4,0,0,0,9,9.8);

	this.circle55 = new lib.circle();
	this.circle55.parent = this;
	this.circle55.setTransform(27.5,78.3,0.4,0.4,0,0,0,9,9.8);

	this.circle54 = new lib.circle();
	this.circle54.parent = this;
	this.circle54.setTransform(31.9,84.6,0.4,0.4,0,0,0,9,9.8);

	this.circle53 = new lib.circle();
	this.circle53.parent = this;
	this.circle53.setTransform(37.2,89.8,0.4,0.4,0,0,0,9,9.8);

	this.circle52 = new lib.circle();
	this.circle52.parent = this;
	this.circle52.setTransform(79.6,97.2,0.4,0.4,0,0,0,9,9.8);

	this.circle51 = new lib.circle();
	this.circle51.parent = this;
	this.circle51.setTransform(86.5,94.2,0.4,0.4,0,0,0,9,9.8);

	this.circle50 = new lib.circle();
	this.circle50.parent = this;
	this.circle50.setTransform(92.7,89.8,0.4,0.4,0,0,0,9,9.8);

	this.circle49 = new lib.circle();
	this.circle49.parent = this;
	this.circle49.setTransform(98,84.4,0.4,0.4,0,0,0,9,9.8);

	this.circle48 = new lib.circle();
	this.circle48.parent = this;
	this.circle48.setTransform(102.3,78.3,0.4,0.4,0,0,0,9,9.8);

	this.circle47 = new lib.circle();
	this.circle47.parent = this;
	this.circle47.setTransform(105.4,71.5,0.4,0.4,0,0,0,9,9.8);

	this.circle46 = new lib.circle();
	this.circle46.parent = this;
	this.circle46.setTransform(107.4,64.2,0.4,0.4,0,0,0,9,9.8);

	this.circle45 = new lib.circle();
	this.circle45.parent = this;
	this.circle45.setTransform(108,56.6,0.4,0.4,0,0,0,9,9.8);

	this.circle44 = new lib.circle();
	this.circle44.parent = this;
	this.circle44.setTransform(107.4,49.2,0.4,0.4,0,0,0,9,9.8);

	this.circle43 = new lib.circle();
	this.circle43.parent = this;
	this.circle43.setTransform(105.4,41.9,0.4,0.4,0,0,0,9,9.8);

	this.circle42 = new lib.circle();
	this.circle42.parent = this;
	this.circle42.setTransform(102.3,35.1,0.4,0.4,0,0,0,9,9.8);

	this.circle41 = new lib.circle();
	this.circle41.parent = this;
	this.circle41.setTransform(97.9,28.9,0.4,0.4,0,0,0,9,9.8);

	this.circle40 = new lib.circle();
	this.circle40.parent = this;
	this.circle40.setTransform(92.7,23.6,0.4,0.4,0,0,0,9,9.8);

	this.circle39 = new lib.circle();
	this.circle39.parent = this;
	this.circle39.setTransform(72.4,14.3,0.4,0.4,0,0,0,9,9.8);

	this.circle38 = new lib.circle();
	this.circle38.parent = this;
	this.circle38.setTransform(64.9,13.5,0.4,0.4,0,0,0,9,9.8);

	this.circle37 = new lib.circle();
	this.circle37.parent = this;
	this.circle37.setTransform(57.5,14.3,0.4,0.4,0,0,0,9,9.8);

	this.circle36 = new lib.circle();
	this.circle36.parent = this;
	this.circle36.setTransform(35.7,39.9,0.4,0.4,0,0,0,9,9.8);

	this.circle35 = new lib.circle();
	this.circle35.parent = this;
	this.circle35.setTransform(33.3,45.3,0.4,0.4,0,0,0,9,9.8);

	this.circle34 = new lib.circle();
	this.circle34.parent = this;
	this.circle34.setTransform(31.8,50.9,0.4,0.4,0,0,0,9,9.8);

	this.circle33 = new lib.circle();
	this.circle33.parent = this;
	this.circle33.setTransform(31.4,56.8,0.4,0.4,0,0,0,9,9.8);

	this.circle32 = new lib.circle();
	this.circle32.parent = this;
	this.circle32.setTransform(31.8,62.5,0.4,0.4,0,0,0,9,9.8);

	this.circle31 = new lib.circle();
	this.circle31.parent = this;
	this.circle31.setTransform(33.2,68.2,0.4,0.4,0,0,0,9,9.8);

	this.circle30 = new lib.circle();
	this.circle30.parent = this;
	this.circle30.setTransform(35.7,73.5,0.4,0.4,0,0,0,9,9.8);

	this.circle29 = new lib.circle();
	this.circle29.parent = this;
	this.circle29.setTransform(39.1,78.3,0.4,0.4,0,0,0,9,9.8);

	this.circle28 = new lib.circle();
	this.circle28.parent = this;
	this.circle28.setTransform(43.3,82.5,0.4,0.4,0,0,0,9,9.8);

	this.circle27 = new lib.circle();
	this.circle27.parent = this;
	this.circle27.setTransform(48,86.1,0.4,0.4,0,0,0,9,9.8);

	this.circle26 = new lib.circle();
	this.circle26.parent = this;
	this.circle26.setTransform(53.4,88.4,0.4,0.4,0,0,0,9,9.8);

	this.circle25 = new lib.circle();
	this.circle25.parent = this;
	this.circle25.setTransform(59,89.8,0.4,0.4,0,0,0,9,9.8);

	this.circle24 = new lib.circle();
	this.circle24.parent = this;
	this.circle24.setTransform(64.7,90.4,0.4,0.4,0,0,0,9,9.8);

	this.circle23 = new lib.circle();
	this.circle23.parent = this;
	this.circle23.setTransform(70.7,89.8,0.4,0.4,0,0,0,9,9.8);

	this.circle22 = new lib.circle();
	this.circle22.parent = this;
	this.circle22.setTransform(76.4,88.4,0.4,0.4,0,0,0,9,9.8);

	this.circle21 = new lib.circle();
	this.circle21.parent = this;
	this.circle21.setTransform(81.5,85.8,0.4,0.4,0,0,0,9,9.8);

	this.circle20 = new lib.circle();
	this.circle20.parent = this;
	this.circle20.setTransform(86.5,82.5,0.4,0.4,0,0,0,9,9.8);

	this.circle19 = new lib.circle();
	this.circle19.parent = this;
	this.circle19.setTransform(90.7,78.1,0.417,0.417,0,0,0,9,9.7);

	this.circle18 = new lib.circle();
	this.circle18.parent = this;
	this.circle18.setTransform(94,73.5,0.415,0.4,0,0,0,9.1,9.6);

	this.circle17 = new lib.circle();
	this.circle17.parent = this;
	this.circle17.setTransform(96.5,68.1,0.417,0.4,0,0,0,9,9.6);

	this.circle16 = new lib.circle();
	this.circle16.parent = this;
	this.circle16.setTransform(97.9,62.5,0.4,0.4,0,0,0,9,9.6);

	this.circle15 = new lib.circle();
	this.circle15.parent = this;
	this.circle15.setTransform(98.4,56.7,0.4,0.4,0,0,0,9,9.6);

	this.circle14 = new lib.circle();
	this.circle14.parent = this;
	this.circle14.setTransform(98,50.9,0.4,0.401,0,0,0,9.1,9.6);

	this.circle12 = new lib.circle();
	this.circle12.parent = this;
	this.circle12.setTransform(93.8,39.8,0.4,0.4,0,0,0,9,9.6);

	this.circle13 = new lib.circle();
	this.circle13.parent = this;
	this.circle13.setTransform(96.5,45.1,0.419,0.4,0,0,0,9.2,9.5);

	this.circle11 = new lib.circle();
	this.circle11.parent = this;
	this.circle11.setTransform(90.5,34.9,0.4,0.4,0,0,0,9,9.6);

	this.circle10 = new lib.circle();
	this.circle10.parent = this;
	this.circle10.setTransform(86.4,30.7,0.4,0.4,0,0,0,9.1,9.6);

	this.circle9 = new lib.circle();
	this.circle9.parent = this;
	this.circle9.setTransform(81.5,27.6,0.4,0.4,0,0,0,9,9.6);

	this.circle8 = new lib.circle();
	this.circle8.parent = this;
	this.circle8.setTransform(76.3,24.9,0.396,0.396,0,0,0,8.8,9.2);

	this.circle7 = new lib.circle();
	this.circle7.parent = this;
	this.circle7.setTransform(70.6,23.4,0.396,0.396,0,0,0,8.8,9.1);

	this.circle6 = new lib.circle();
	this.circle6.parent = this;
	this.circle6.setTransform(64.6,22.8,0.396,0.396,0,0,0,8.8,9.1);

	this.circle5 = new lib.circle();
	this.circle5.parent = this;
	this.circle5.setTransform(58.8,23.4,0.396,0.396,0,0,0,8.8,9.1);

	this.circle4 = new lib.circle();
	this.circle4.parent = this;
	this.circle4.setTransform(53.1,24.9,0.396,0.396,0,0,0,8.8,9.2);

	this.circle3 = new lib.circle();
	this.circle3.parent = this;
	this.circle3.setTransform(47.9,27.2,0.396,0.396,0,0,0,8.8,9.2);

	this.circle2 = new lib.circle();
	this.circle2.parent = this;
	this.circle2.setTransform(43.2,30.6,0.396,0.396,0,0,0,8.8,9.2);

	this.circle1 = new lib.circle();
	this.circle1.parent = this;
	this.circle1.setTransform(39,34.8,0.396,0.396,0,0,0,9,9.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.circle1},{t:this.circle2},{t:this.circle3},{t:this.circle4},{t:this.circle5},{t:this.circle6},{t:this.circle7},{t:this.circle8},{t:this.circle9},{t:this.circle10},{t:this.circle11},{t:this.circle13},{t:this.circle12},{t:this.circle14},{t:this.circle15},{t:this.circle16},{t:this.circle17},{t:this.circle18},{t:this.circle19},{t:this.circle20},{t:this.circle21},{t:this.circle22},{t:this.circle23},{t:this.circle24},{t:this.circle25},{t:this.circle26},{t:this.circle27},{t:this.circle28},{t:this.circle29},{t:this.circle30},{t:this.circle31},{t:this.circle32},{t:this.circle33},{t:this.circle34},{t:this.circle35},{t:this.circle36},{t:this.circle37},{t:this.circle38},{t:this.circle39},{t:this.circle40},{t:this.circle41},{t:this.circle42},{t:this.circle43},{t:this.circle44},{t:this.circle45},{t:this.circle46},{t:this.circle47},{t:this.circle48},{t:this.circle49},{t:this.circle50},{t:this.circle51},{t:this.circle52},{t:this.circle53},{t:this.circle54},{t:this.circle55},{t:this.circle56},{t:this.circle57},{t:this.circle58},{t:this.circle59},{t:this.circle60},{t:this.circle61},{t:this.circle62},{t:this.circle63},{t:this.circle64},{t:this.circle65},{t:this.circle66},{t:this.circle67},{t:this.circle68},{t:this.circle69},{t:this.circle70},{t:this.circle71},{t:this.circle72},{t:this.circle73},{t:this.circle74},{t:this.circle75},{t:this.circle76},{t:this.circle77},{t:this.circle78},{t:this.circle79},{t:this.circle80},{t:this.circle81},{t:this.circle82},{t:this.circle83},{t:this.circle84},{t:this.circle85},{t:this.circle86},{t:this.circle87},{t:this.circle88},{t:this.circle89},{t:this.circle90},{t:this.circle91},{t:this.circle92},{t:this.circle93},{t:this.circle94},{t:this.circle95},{t:this.circle96},{t:this.circle97},{t:this.circle98},{t:this.circle99},{t:this.circle100},{t:this.circle101},{t:this.circle102},{t:this.circle103},{t:this.circle104}]}).wait(1));

	// AuroraMid
	this.nbnMid = new lib.nbnMid();
	this.nbnMid.parent = this;
	this.nbnMid.setTransform(64.9,56.5,1,1,0,0,0,26.6,26.8);

	this.timeline.addTween(cjs.Tween.get(this.nbnMid).wait(1));

}).prototype = getMCSymbolPrototype(lib.NBNlogo, new cjs.Rectangle(0,0,133,131.8), null);


// stage content:
(lib.LogoAnimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var nbnroot = this,
			nbnClip, nbnTrail;
		
		nbnClip = eval("nbnroot.NBNlogo");
		nbnTrail = eval("nbnroot.NBNtrail");
		
		TweenMax.from(nbnClip, 2.5, {rotation:-70, delay:2.0, ease:Expo.easeOut});
		TweenMax.from(nbnTrail, 3, {rotation:-15, delay:0.1, ease:Expo.easeOut});
		TweenMax.to(nbnroot.nbn, 1, {alpha:1, delay:1.25, ease:Sine.easeInOut});
	}
	this.frame_33 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(33).call(this.frame_33).wait(1));

	// nbn
	this.nbn = new lib.nbn();
	this.nbn.parent = this;
	this.nbn.setTransform(304.8,186.5,2.108,2.108,0,0,0,58.1,20.7);
	this.nbn.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.nbn).wait(34));

	// NBNLogo
	this.NBNlogo = new lib.NBNlogo();
	this.NBNlogo.parent = this;
	this.NBNlogo.setTransform(409,166.7,0.732,0.732,0,0,0,68.6,68);

	this.timeline.addTween(cjs.Tween.get(this.NBNlogo).wait(34));

	// Trail
	this.NBNtrail = new lib.NBNtrail();
	this.NBNtrail.parent = this;
	this.NBNtrail.setTransform(469.1,145.4,1.001,1.001,0,0,0,8,28.5);

	this.timeline.addTween(cjs.Tween.get(this.NBNtrail).wait(34));

	// CTA
	this.instance = new lib.cta();
	this.instance.parent = this;
	this.instance.setTransform(325.5,292.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({alpha:1},13,cjs.Ease.get(-0.99)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(320,240,640,480);
// library properties:
lib.properties = {
	id: '19067B42499B4B3B88FC0E0EBF6A49BB',
	width: 640,
	height: 480,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['19067B42499B4B3B88FC0E0EBF6A49BB'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;